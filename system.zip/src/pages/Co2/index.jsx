
import React,{useEffect,useState,useRef} from "react";
import { PageContainer, ProFormSelect} from '@ant-design/pro-components';
import {Button,Row,Col,Card,Space} from 'antd'
import { PlusOutlined  } from '@ant-design/icons';
import ZForm from './ZForm'

const Index=()=>{
    const actionRef = useRef()



    const handleClick=()=>{

    }
    const toolBar=() => [
        <Button
          type="primary"
          key="primary"
          onClick={handleClick}
        >
          <PlusOutlined /> {'新建'}
        </Button>,
      ]

     const options=[
      {
        value: 'jack',
        label: 'Jack',
      },
      {
        value: 'lucy',
        label: 'Lucy',
      },
      {
        value: 'tom',
        label: 'Tom',
      },
     ]
    return <PageContainer>
       <Row gutter={[16, 16]}>
        <Col span={6} >
          <Card
          headStyle={{height:200,paddingTop:20,justifyContent:'flex-start'}}
          bodyStyle={{height:150}}
          title={
            <div>
              <ProFormSelect
                  showSearch={{filter:(inputValue,path)=>path.some((option) => option.label.toLowerCase().indexOf(inputValue.toLowerCase()) > -1)}}
                  width="md"
                  name="title1"
                  label={'公司'}
                  options={options}
              />
              <div>
                <Space>
                  年度碳排放量：<div style={{fontSize:13}}>0</div>
                </Space>
              </div>
              <div style={{margin:'20px 0'}}>
              <Space>
                  审核公司：<div style={{fontSize:13}}>无</div>
                </Space>
              </div>
            </div>
          }
          >
              <ZForm />
          </Card>
        </Col>
        <Col span={6} >
          <Card
              headStyle={{height:200,paddingTop:20,justifyContent:'flex-start'}}
             bodyStyle={{height:150}}
             title={
              <div >
                <ProFormSelect
                    showSearch={{filter:(inputValue,path)=>path.some((option) => option.label.toLowerCase().indexOf(inputValue.toLowerCase()) > -1)}}
                    width="md"
                    name="title1"
                    label={'公司'}
                    options={options}
                />
                <div>
                  <Space>
                    本年度碳排放密度：<div style={{fontSize:13}}>0</div>
                  </Space>
                </div>
                  <div>
                    <Space>
                    剩余碳排放额：<div style={{fontSize:13}}>0</div>
                    </Space>
                  </div>
                  <div>
                    <Space>
                      可补贴金额：<div style={{fontSize:13}}>0</div>
                    </Space>
                  </div>
                  <div>
                    <Space>
                    可贷款金额：<div style={{fontSize:13}}>0</div>
                  </Space>
                  </div>
                  
              </div>
            }
          >
            <div>
                 <Space>
                      申请补贴<div style={{fontSize:13}}>0</div>
                  </Space>
                  </div>
                  <div>
                    <Space>
                    申请金额<div style={{fontSize:13}}>0</div>
                  </Space>
                  </div>
                  <div style={{position:'absolute',width:'fit-content',right:24,bottom:8}}>
                    <Button type="primary">申请</Button>
                  </div>
          </Card>
        </Col>
        <Col span={6} >
        <Card
             headStyle={{height:200,paddingTop:20,justifyContent:'flex-start'}}
             bodyStyle={{height:150}}
             title={
              <div >
                <ProFormSelect
                    showSearch={{filter:(inputValue,path)=>path.some((option) => option.label.toLowerCase().indexOf(inputValue.toLowerCase()) > -1)}}
                    width="md"
                    name="title1"
                    label={'type查询'}
                    options={options}
                />
                <div>
                  <Space>
                    公司名：<div style={{fontSize:13}}>0</div>
                  </Space>
                </div>
                  <div>
                    <Space>
                    本年排放量：<div style={{fontSize:13}}>0</div>
                    </Space>
                  </div>
                  <div>
                    <Space>
                      审核公司：<div style={{fontSize:13}}>0</div>
                    </Space>
                  </div>  
              </div>
            }
          >
            <div style={{position:'absolute',width:'fit-content',right:24,bottom:8}}>
                    <Button type="primary">审核</Button>
                  </div>
          </Card>
        </Col>
        <Col span={6} >
            <Card
                headStyle={{height:200,paddingTop:20,justifyContent:'flex-start'}}
                bodyStyle={{height:150}}
                title={
                  <div >
                    <ProFormSelect
                        showSearch={{filter:(inputValue,path)=>path.some((option) => option.label.toLowerCase().indexOf(inputValue.toLowerCase()) > -1)}}
                        width="md"
                        name="title1"
                        label={'申请补贴'}
                        options={options}
                    />
                    <ProFormSelect
                        showSearch={{filter:(inputValue,path)=>path.some((option) => option.label.toLowerCase().indexOf(inputValue.toLowerCase()) > -1)}}
                        width="md"
                        name="title1"
                        label={'申请贷款'}
                        options={options}
                     />
                  </div>
                }
              >
                <div style={{position:'absolute',width:'fit-content',right:24,bottom:8}}>
                        <Button type="primary">通过</Button>
                      </div>
              </Card>
        </Col>
      </Row>
    </PageContainer>
}
export default Index