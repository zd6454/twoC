import { ProFormUploadButton,ProForm } from '@ant-design/pro-components';
import React,{useState} from 'react';
import { PlusOutlined } from '@ant-design/icons';


const Index=(props)=>{
    const {modelRef,onfinish,bansks}=props;

    return <div>
        <ProForm
        formRef={modelRef}
        onFinish={onfinish}
        submitter={{
            render: (_, dom) => <div style={{float:'right'}}>{dom[1]}</div>,
          }}
      >
       <ProFormUploadButton
          label='上传材料'
          width="md"
          name="img"
          max={1}
          icon={<PlusOutlined />}
        />
      </ProForm>
    </div>
}
export default Index;